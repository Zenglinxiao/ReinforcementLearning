import numpy as np
np.random.seed(0)
"""
Contains the definition of the agent that will run in an
environment.
"""

class RandomAgent:
    def __init__(self):
        """Init a new agent.
        """

    def choose(self):
        """Acts given an observation of the environment.

        Takes as argument an observation of the current state, and
        returns the chosen action.
        """
        return np.random.randint(0, 10)

    def update(self, action, reward):
        """Receive a reward for performing given action on
        given observation.

        This is where your agent can learn.
        """
        pass

class epsGreedyAgent:
    def __init__(self):
        """
        A: bandit arm K
        epsilon
        count: count for chosen arm i
        value: average reward for chosen arm i -Q(i)
        """
        self.A = [0,1,2,3,4,5,6,7,8,9]
        self.epsilon = 0.10 #0.128 0.13
        self.count = np.zeros(len(self.A))
        self.value = np.zeros(len(self.A))

    def choose(self):
        #raise NotImplemented
        if np.random.random_sample() < self.epsilon:
            action = np.random.randint(self.value.shape[0])
        else:
            action = np.argmax(self.value)
        return  action

    def update(self, action, reward):
        #raise NotImplemented
        self.value[action] = (self.value[action] * self.count[action] + reward)/(self.count[action] + 1)
        self.count[action] += 1
        return

class BesaAgent():
    # https://hal.archives-ouvertes.fr/hal-01025651v1/document
    """#Best Empirical Sampled Average -> make a fair comparison between the arms\n
    fair? -> Given two arms a and b that has been pulled na nb(>na) respectively at time t
    comparing the empirical averages of the arms is not a fair comparison since a has not
    gotten the same number of opportunities as b to show its abilities\n
    HOW? -> [sub-sampling] uniformly na rewards out of the nb rewards of arm b.
    """
    def __init__(self):
        self.A = [0,1,2,3,4,5,6,7,8,9]
        self.count = np.zeros(len(self.A)).astype(int)
        self.values_sampleset = [[] for i in range(len(self.A))]

    def choose(self):
        #raise NotImplemented
        if 0 in self.count:
            action = self.count.tolist().index(0)
        else:
            #print(self.values_sampleset)
            action = self.besa(self.A)
        return action

    def update(self, action, reward):
        #raise NotImplemented
        self.values_sampleset[action].append(reward)
        self.count[action] += 1
        return

    def besa(self,arms):
        #do a shuffle, then divide&conquer
        np.random.shuffle(arms)
        #print(arms)
        lens = len(arms)
        if lens == 1:
            return arms[0]
        else:
            divide_point = lens//2
            return self.besafor2(self.besa(arms[ :divide_point]),self.besa(arms[divide_point: ]))

    def besafor2(self,a,b):##?????
        # 2 arms a b
        #if self.count[a]<self.count[b]:
            #ia = self.subsamping(a,a)
            #ib = self.subsamping(b,a)
        #else:
            #ia = self.subsamping(a,b)
            #ib = self.subsamping(b,b)
        na = self.count[a]
        nb = self.count[b]
        index_a = np.random.choice(na,min(na, nb),replace=False)
        index_b = np.random.choice(nb,min(na, nb),replace=False)
        #print(na," - ", nb)
        #index_a, index_b = self.subsamping(na,nb)
        #print(index_a," - ", index_b)
        miu_a = np.mean(np.take(self.values_sampleset[a], index_a))
        miu_b = np.mean(np.take(self.values_sampleset[b], index_b))
        action = a if miu_a > miu_b else b
        return action

    # def subsamping(self,na,nb):
    #     if na < nb:
    #         index_a = np.random.choice(na,na,replace=False)
    #         index_b = np.random.choice(nb,na,replace=False)
    #         return index_a, index_b
    #     else:
    #         index_a = np.random.choice(na,nb,replace=False) 
    #         index_b = np.random.choice(nb,nb,replace=False)
    #         return index_a, index_b

class SoftmaxAgent:
    # https://www.cs.mcgill.ca/~vkules/bandits.pdf
    def __init__(self):
        """
        A: bandit arm K=len(A)\n
        count: count for chosen arm i\n
        Q: average reward for chosen arm i -Q(i)\n
        tau: temperature parameter(controlling the randomness of the choice) 
            tau=0 exploitation only;tau=inf exploration only
        """
        self.A = [0,1,2,3,4,5,6,7,8,9]
        self.count = np.zeros(len(self.A))
        self.Q = np.zeros(len(self.A))
        self.tau = 0.202    #0.202 0.203 0.204 0.205

    def choose(self):
        #according to boltzmann distribution:P(k)=exp(exp(Q(i)/tau))/SUM_i(exp(Q(i)/tau))
        denominator = np.sum(np.exp([self.Q[i]/self.tau for i in range(len(self.A))]))
        p_boltzmann_K = np.exp([self.Q[i]/self.tau for i in range(len(self.A))])/denominator
        action = np.random.choice(self.A, p = p_boltzmann_K)
        return  action

    def update(self, action, reward):
        #raise NotImplemented
        self.Q[action] = (self.Q[action] * self.count[action] + reward)/(self.count[action] + 1)
        self.count[action] += 1
        return

class UCBAgent:
    '''
    https://homes.di.unimi.it/~cesabian/Pubblicazioni/ml-02.pdf \n
    Upper Confidence Bounds : measures the potential to have a optimal value 
        by an upper confidence bound of the reward value(Ut(act)),so that the 
        true value is below with bound Q(act)<=Qt(act)+Ut(act) with high probability.
        How to estimate the upper confidence bound ? >> for UCB1 : sqrt(2*log(t)/Nt(a))
    '''
    def __init__(self):
        """
        A: bandit arm K=len(A)\n
        counts: count for chosen arm i\n
        average_rewards: average reward for chosen arm i -average_rewards(i)\n
        unexplored: number of arms that haven't been chosen, used for initialisation
        """
        self.A = [0,1,2,3,4,5,6,7,8,9]
        self.counts = np.zeros(len(self.A))
        self.average_rewards = np.zeros(len(self.A))
        self.unexplored = len(self.A)
        #play each once

    def choose(self):
        if (self.unexplored != 0):
            #init - explore all the unexplored machine:
            action = np.argmin(self.counts)
            self.unexplored -= 1
        else:#after all machine have been played
            action = np.argmax(self.average_rewards + np.sqrt(2*np.log(np.sum(self.counts))/self.counts))
        return action

    def update(self, a, r):
        self.average_rewards[a] = (self.average_rewards[a] * self.counts[a] + r)/(self.counts[a] + 1)
        self.counts[a] += 1
        return

#How to deal with the bound
class ThompsonAgent:
    # https://en.wikipedia.org/wiki/Thompson_sampling
    # https://arxiv.org/abs/1111.1797   adapt algorithm 2: Thompson sampling for general stochastic bandits
    def __init__(self):
        '''
        A: bandit arm K=len(A)\n
        S: number of successes for arms
        F: number of failures for arms
        '''
        self.A = [0,1,2,3,4,5,6,7,8,9]
        self.S = np.zeros(len(self.A))
        self.F = np.zeros(len(self.A))


    def choose(self):
        #raise NotImplemented
        sample = [np.random.beta(self.S[i]+1,self.F[i]+1) for i in range(len(self.A))]
        action = np.argmax(sample)
        return action

    def update(self, a, r):
        #raise NotImplemented
        #print(r)    # r is not bounded to [0,1]([-10,10])
        #rt = np.random.binomial(1,(r+10)/20) ## should i normalise that???
        if(r > 0):
            self.S[a] +=r
        else:
            self.F[a] -=r
        return

#How to achieve newton iteration??
class KLUCBAgent:
    # See: https://hal.archives-ouvertes.fr/hal-00738209v2 page 8 ? 14
    # http://arxiv.org/pdf/1102.2490.pdf
    def __init__(self):
        """
        A: bandit arm K=len(A)\n
        counts: count for chosen arm i\n
        acc_rewards: accumulate reward for chosen arm i -rewards(i)\n
        unexplored: number of arms that haven't been chosen, used for initialisation
        """
        self.A = [0,1,2,3,4,5,6,7,8,9]
        self.counts = np.zeros(len(self.A))
        self.acc_rewards = np.zeros(len(self.A))
        self.explored = 0


    def choose(self):#d(p,q) = p*log(p/q) + (1-p)*log((1-p)/(1-q))
        #raise NotImplemented
        if (self.explored < 10):
            #init - explore all the unexplored machine:
            action = np.argmin(self.counts)
            self.explored += 1
        else:#after all machine have been played
            p = self.acc_rewards/self.counts
            ft = np.log(np.sum(self.counts))
            U = []
            for act in self.A:
                sup_q = -10
                for q in np.linspace(-10,10,400):
                    if self.d(p[act],q) < ft / self.counts[act]:
                        sup_q = max(sup_q, q)
                U.append(sup_q)
            # q =?
            # d = p*np.log(p/q) + (1-p)*np.log((1-p)/(1-q))
            # na_d = self.counts * d
            # #use newton iteration to get q for f(q) = na_d - ft =0? HOW??
            action = np.argmax(U)
        return action

    def d(self,p,q):
        return p*np.log(p/q) + (1-p)*np.log((1-p)/(1-q))


    def update(self, a, r):
        #raise NotImplemented
        self.acc_rewards[a]+=r
        self.counts[a]+=1
    

# Choose which Agent is run for scoring
Agent = ThompsonAgent
'''
SoftmaxAgent: 1692 - 1690 - 1689.8 - 1688.67
epsGredy: 1682 - 1654.83
Besa: 
UCB:
Thompson:1298
KLUCBAgent: 
'''